<?php
/**
 * @package WordPress
 * @subpackage
 * @since
 * @version 1.0
 */

?>
	

<?php get_header(); ?>

<main>
  <br>
         <div>
      <div class="row column text-center">
        <h2 class="subheader">Blog Title</h2>
      </div>
    </div>

<!--Category Boxes-->
    <div class="bottom-container">
    <div class="grid-x align-bottom">

    <div class="small-4 medium-4 cell">
        <div class="cat-box">
            <a class="cat-link" href="category"><img src="/wordpress/wp-content/themes/lego/assets/img/placeholder.png" alt=""></a>
    </div>
    </div>

<div class="small-4 medium-4 cell">
    <div class="cat-box">
        <a class="cat-link" href="category"><img src="/wordpress/wp-content/themes/lego/assets/img/placeholder.png" alt=""></a>
</div>
</div>


<div class="small-4 medium-4 cell">
    <div class="cat-box">
        <a class="cat-link" href="category"><img src="/wordpress/wp-content/themes/lego/assets/img/placeholder.png" alt=""></a>
</div>
</div>


<div class="small-4 medium-4 cell">
    <div class="cat-box">
        <a class="cat-link" href="category"><img src="/wordpress/wp-content/themes/lego/assets/img/placeholder.png" alt=""></a>
</div>
</div>

<div class="small-4 medium-4 cell">
<div class="cat-box">
    <a class="cat-link" href="category"><img src="/wordpress/wp-content/themes/lego/assets/img/placeholder.png" alt=""></a>
</div>
</div>


<div class="small-4 medium-4 cell">
<div class="cat-box">
    <a class="cat-link" href="category"><img src="/wordpress/wp-content/themes/lego/assets/img/placeholder.png" alt=""></a>
</div>
</div>
</div>

</div>

<!--posts 6?-->

<h3 class="excerpt-post-title">Latest Posts</h3>

<div class="bottom-container">
  <div class="grid-x align-bottom">
    <div class="medium-2 cell">
      <div class="media-object">
        <div class="media-object-section">
        </div>
         
        </div>
      </div>


    </div>
    <div class="medium-2 cell">
      <div class="media-object">
        <div class="media-object-section">
          <img class="thumbnail" src="/wordpress/wp-content/themes/lego/assets/img/placeholder.png" alt="">
        </div>
        <div class="media-object-section">
          <h5>Post Title</h5>
    <p>Lorem ipsum dolor sit amet, consectetur
      adipiscing elit. Lorem ipsum dolor sit amet, consectetur
      adipiscing elit. Lorem ipsum dolor sit amet, consectetur
      adipiscing elit.</p>
      <a href="page-single-post.php">Read More</a>
        </div>
      </div>

    </div>
    <div class="medium-2 cell">
      <div class="media-object">
        <div class="media-object-section">
          <img class="thumbnail" src="/wordpress/wp-content/themes/lego/assets/img/placeholder.png" alt="">
        </div>
        <div class="media-object-section">
          <h5>Post Title</h5>
    <p>Lorem ipsum dolor sit amet, consectetur
      adipiscing elit. Lorem ipsum dolor sit amet, consectetur
      adipiscing elit. Lorem ipsum dolor sit amet, consectetur
      adipiscing elit.</p>
      <a href="single-blog-page.html">Read More</a>
        </div>
      </div>

    </div>
    <div class="medium-2 cell">
      <div class="media-object">
        <div class="media-object-section">
          <img class="thumbnail" src="/wordpress/wp-content/themes/lego/assets/img/placeholder.png" alt="">
        </div>
        <div class="media-object-section">
          <h5>Post Title</h5>
    <p>Lorem ipsum dolor sit amet, consectetur
      adipiscing elit. Lorem ipsum dolor sit amet, consectetur
      adipiscing elit. Lorem ipsum dolor sit amet, consectetur
      adipiscing elit.</p>
      <a href="single-blog-page.html">Read More</a>
        </div>
      </div>
      
    </div>
    <div class="medium-2 cell">
      <div class="media-object">
        <div class="media-object-section">
          <img class="thumbnail" src="/wordpress/wp-content/themes/lego/assets/img/placeholder.png" alt="">
        </div>
        <div class="media-object-section">
          <h5>Post Title</h5>
    <p>Lorem ipsum dolor sit amet, consectetur
      adipiscing elit. Lorem ipsum dolor sit amet, consectetur
      adipiscing elit. Lorem ipsum dolor sit amet, consectetur
      adipiscing elit.</p>
      <a href="single-blog-page.html">Read More</a>
        </div>
      </div>

    </div>
    <div class="medium-2 cell">

      <div class="media-object">
        <div class="media-object-section">
          <img class="thumbnail" src="/wordpress/wp-content/themes/lego/assets/img/placeholder.png" alt="">
        </div>
        <div class="media-object-section">
          <h5>Post Title</h5>
    <p>Lorem ipsum dolor sit amet, consectetur
      adipiscing elit. Lorem ipsum dolor sit amet, consectetur
      adipiscing elit. Lorem ipsum dolor sit amet, consectetur
      adipiscing elit.</p>
      <a href="single-blog-page.html">Read More</a>
        </div>
      </div>

    </div>
  </div>
</div>

      <br>
    </main>