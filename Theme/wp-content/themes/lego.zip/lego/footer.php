<br>
    <footer>
      <div class="top-bar align-center" id="main-menu">
        <ul class="menu vertical medium-horizontal">
              <li class="menu-text hide-for-small-only"><a href="#home">Back to the Top</a></li>
              <li class="menu-text hide-for-small-only"><a href="index.html">Home</a></li>
              <li class="menu-text hide-for-small-only"><a href="single-blog-page.html">Post</a></li>
              <li class="menu-text hide-for-small-only"><a href="about.html">About</a></li>
              <li class="menu-text hide-for-small-only"><a href="contact.html">Contact</a></li>
              <li class="menu-text hide-for-small-only"><a href="#">Twitter</a></li>
            </ul>
      </div>
    </footer>

    <script src="https://code.jquery.com/jquery-2.1.4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/foundation/6.4.5/js/foundation.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/motion-ui/1.2.5/motion-ui.min.js"></script>
    <script>
      $(document).foundation();
    </script>

<?php wp_footer(); ?>
</body>
</html>